<?php
/**
 * using mysqli_connect for database connection
 */
 
$databaseHost = 'localhost';
$databaseName = 'um29xl32_gere';
$databaseUsername = 'um29xl32_root';
$databasePassword = '3JJ!z^4b48cP';
 
$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
 
?>