<?php

$today = date("Y-m");
echo $today;